#include "lab4_util.h"

#define SYS_EXIT 1
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_ISEEK 19

#define STDIN 0
#define STDOUT 1
#define STDERR 2

#define O_RDRW 2
#define O_CREAT 64

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

#define EOF 4
int debug_mode_flag = 0;
extern int system_call(int op_code, ...); 

int open(const char *path, int oflag, int mode_t);
int close(const char *path);
int read(int fd, const char *input_buff, int number_of_bytes_to_read);
int write(int fd, const char *output_buff, int number_of_bytes_to_write);
int seek(int fd, int offset, int seek);
int my_exit(int status);
void err_exit();

/* given file descributor - return the size of the file in bytes. */
int get_file_size(int fd);
void debugWrite(int sys_call_ID, int sys_call_ret);

int main (int argc , char* argv[], char* envp[])
{
  int input_fd = STDIN;
  int output_fd = STDOUT;

  char i_buff[1];
  char * o_buff;
  char * output_buff;
  int count = 0, input_flag = -1, output_flag = -1, i;

  /*write(STDOUT, "before for \n", strlen("before for \n"));*/

  for(i = 1; i < argc; i++){
    if(strncmp("-D", argv[i], 2) == 0) {debug_mode_flag = 1;}

    if(strncmp("-i", argv[i], 2) == 0) {input_flag = i;}
    
    if(strncmp("-o", argv[i], 2) == 0) {output_flag = i;}
  }

  /*write(STDOUT, "after for \n", strlen("after for \n"));*/

  if(input_flag != -1){
    /*write(STDOUT, "OpenOpen IN\n", strlen("OpenOpen IN\n"));*/
    input_fd = open(argv[input_flag] + 2, O_RDRW, 0);
  }
  
  if(output_flag != -1){
    /*write(STDOUT, "OpenOpen Out\n", strlen("OpenOpen Out\n"));*/
    output_fd = open(argv[output_flag] + 2, O_CREAT, 0777);
  }

  /*write(STDOUT, "before while \n", strlen("before while \n"));*/
  if(debug_mode_flag){
    debug_mode_flag = 0;
    write(STDERR, "in: ", strlen("in: "));
    if(input_fd == STDIN){
      output_buff = "STDIN";
    }else{
      output_buff = itoa(input_fd);  
    }
    write(STDERR, output_buff, strlen(output_buff));
    write(STDERR, " out: ", strlen(" out: "));
    if(input_fd == STDOUT){
      output_buff = "STDOUT";
    }else{
      output_buff = itoa(output_fd);  
    }
    write(STDERR, output_buff, strlen(output_buff));
    write(STDERR, "\n", strlen("\n"));
    debug_mode_flag = 1;
  }
  
  while(i_buff[0] != EOF){

	  while(i_buff[0] != '\n'){

		  while(i_buff[0] == ' ')
			  read(input_fd, i_buff, 1); 
        
		  if(i_buff[0] == '\n') break;
      
		  while(i_buff[0] != ' ' && i_buff[0] != '\n')
			  read(input_fd, i_buff, 1);

		  count++;
	  }
    o_buff = itoa(count);
	  write(output_fd, o_buff, strlen(o_buff));
	  count = 0;
	  write(output_fd, "\n", 1);
	  read(input_fd, i_buff, 1);
  }
  
  
  my_exit(0);
  return 0;  
  
}

int open(const char *path, int oflag, int mode_t){    
    int ret=-1;
    ret = system_call(SYS_OPEN,path,oflag,mode_t);
    if (ret < 0){
      err_exit();
    }
    debugWrite(SYS_OPEN, ret);
    return ret;
}

int close(const char *path){
    int ret=-1;
    ret = system_call(SYS_CLOSE,path);
    if (ret < 0){
      err_exit();
    }
    debugWrite(SYS_CLOSE, ret);
    return ret;
}

int read(int fd, const char *input_buff, int number_of_bytes_to_read){
    int ret=-1;
    ret = system_call(SYS_READ, fd, input_buff, number_of_bytes_to_read);
    if (ret < 0 || (ret==0 && number_of_bytes_to_read>0)){
      err_exit();
    }
    debugWrite(SYS_READ, ret);
    return ret;
}

int write(int fd, const char *output_buff, int number_of_bytes_to_write){
    int ret=-1;
    ret = system_call(SYS_WRITE,fd,output_buff,number_of_bytes_to_write);
    if (ret < 0 || (ret==0 && number_of_bytes_to_write>0)){
      err_exit();
    }
    debugWrite(SYS_WRITE, ret);
    return ret;
}

int seek(int fd, int offset, int seek){
    int ret=-1;
    ret = system_call(SYS_ISEEK,fd,offset,seek);
    if (ret == 0 && ((offset>0 && seek==0) || seek!=0)){
      err_exit();
    }
    debugWrite(SYS_ISEEK, ret);
    return ret;
}

int my_exit(int status){
  return system_call(SYS_EXIT,status);
}

void err_exit(){
  my_exit(0x55);
}

int get_file_size(int fd){
  int file_size, cur_fd_pos;
  cur_fd_pos = seek(fd, 0,SEEK_CUR);
  file_size = seek(fd,0,SEEK_END)+1;
  seek(fd,cur_fd_pos,SEEK_SET);
  return file_size;
}

void debugWrite(int sys_call_ID, int sys_call_ret){
  char * output_buff;
  if(debug_mode_flag){
    debug_mode_flag = 0;  /* turn off debug debug_mode_flag to avoid syscall write recursion */

    /*write(STDOUT, "in debug write", strlen("in debug write"));*/
    write(STDERR, "\ndebug: ", strlen("\ndebug: "));
    output_buff = itoa(sys_call_ID);
    write(STDERR, output_buff, strlen(output_buff));
    write(STDERR, " ", 1);
    output_buff = itoa(sys_call_ret);
    write(STDERR, output_buff, strlen(output_buff));
    write(STDERR, "\n", 1);

    /*write(STDOUT, "out debug write", strlen("out debug write"));*/

    debug_mode_flag = 1;
  }
}
