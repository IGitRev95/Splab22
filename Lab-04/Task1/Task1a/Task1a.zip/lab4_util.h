unsigned int strlen (const char *str);
int strcmp(const char *str1, const char *str2); 
int strncmp(const char* str1, const char* str2, unsigned int n);
char *itoa(int num);
int positive_atoi(char* str);
char *strcat(char *dest, char *src);
char *strncat(char *dest, char *src, int n);